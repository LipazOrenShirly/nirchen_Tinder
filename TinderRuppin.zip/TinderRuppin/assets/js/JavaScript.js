﻿users = [
    {
        id: 0,
        name: "Rachel Greene",
        gender: "Female",
        age: 50,
        height: 160,
        city: "New York",
        image: "assets/images/Rachel Greene.jpg",
        premium: true,
        hobbies: ["be photographed", "travel the world"]
    },
    {
        id: 1,
        name: "Phoebe Buffay",
        gender: "Female",
        age: 52,
        height: 170,
        city: "New York",
        image: "assets/images/Phoebe Buffay.png",
        premium: true,
        hobbies: ["Singing out od notes"]
    },
    {
        id: 3,
        name: "Ross Geller",
        gender: "Male",
        age: 52,
        height: 175,
        city: "New York",
        image: "assets/images/RossGeller.jpg",
        premium: true,
        hobbies: ["dinozaurs"]
    },
    {
        id: 4,
        name: "Monica Geller",
        gender: "Female",
        age: 50,
        height: 160,
        city: "New York",
        image: "assets/images/Monica Geller.jpg",
        premium: true,
        hobbies: ["Cleaning, Cooking"]
    },
    {
        id: 5,
        name: "Chandler Bing",
        gender: "Male",
        age: 51,
        height: 175,
        city: "New York",
        image: "assets/images/Chandler Bing.jpg",
        premium: false,
    },
    {
        id: 6,
        name: "Joey Tribbiani",
        gender: "Male",
        age: 52,
        height: 180,
        city: "New York",
        image: "assets/images/Joey.png",
        premium: true,
        hobbies: ["Eating"]
    },
    {
        id: 7,
        name: "bar refaeli",
        gender: "Female",
        age: 38,
        height: 170,
        city: "netanya",
        image: "assets/images/bar_refaeli.jpg",
        premium: true,
        hobbies: ["be photographed", "travel the world"]
        },
        {
        id: 8,
        name: "assi azar",
        gender: "Male",
        age: 40,
        height: 180,
        city: "tel-aviv",
        image: "assets/images/assi_azar.jpg",
        premium: true,
        hobbies: ["Harassing people"]
        },
        {
        id: 9,
        name: "Noa killer",
        gender: "Female",
        age: 18,
        height: 170,
        city: "tel-aviv",
        image: "assets/images/noa_killer.jpg",
        premium: false
        },
        {
        id: 10,
        name: "Justin bieber",
        gender: "Male",
        age: 25,
        height: 170,
        city: "kanada",
        image: "assets/images/justin_bieber.jpg",
        premium: false
        }
];
