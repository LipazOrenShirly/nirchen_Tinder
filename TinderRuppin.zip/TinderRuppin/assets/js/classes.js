﻿class Profile {
    constructor(id, name, gender, age, height, city, image, premium) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.height = height;
        this.city = city;
        this.image = image;
        this.premium = premium;
    }
 
    Render() { 
        let str = '<div class="row"><div class="col-lg-12"><div class="center-heading"><h2 class="section-title">' + this.name + '</h2></div></div><div class="offset-lg-3 col-lg-6"><div class="center-text"><p>Age: ' + this.age + '</p><p>Height: ' + this.height + '</p><p>City: ' + this.city + '</p></div></div></div><div class="row"><div class="col-lg-12"><div class="blog-post-thumb"><div class="img"><img src="' + this.image + '" alt=""></div></div></div></div>';
        document.getElementById("ph").innerHTML += str;
    }
}

class Premium extends Profile {
    constructor(id, name, gender, age, height, city, image, premium, hobbies) {
        super(id, name, gender, age, height, city, image, premium)
        this.hobbies = hobbies;
    }
    get Hobbies() { return this.hobbies; }

    Render() {
        super.Render() 
        let str2 = '<div class="row"><div class="offset-lg-3 col-lg-6"><div class="center-text"><p>Hobbies: ' + this.hobbies + '</p></div ></div ></div >';
        document.getElementById("ph").innerHTML += str2;
    }
    
}

class MainApp {
   
    constructor(users, counter, conditions) {

        this.counter = counter;
        this.all = [];
        this.filtered = [];
        this.conditions = conditions;

        for (var i = 0; i < users.length; i++) {
            if (users[i].premium == true) {
                let prem = new Premium(users[i].id, users[i].name, users[i].gender, users[i].age, users[i].height, users[i].city, users[i].image, users[i].premium, users[i].hobbies);
                this.all.push(prem);

            }
            else {
                let prof = new Profile(users[i].id, users[i].name, users[i].gender, users[i].age, users[i].height, users[i].city, users[i].image, users[i].premium);
                this.all.push(prof);
            }
        }

        this.filtered = this.Filter(this.conditions);
        if (this.filtered.length == 0) {
            alert('There is no matches');
            window.location.href = 'index.html';         
        }
    }
  

    Filter(conditions) {
        return this.all.filter(index => index.age >= conditions.min && index.age <= conditions.max && index.gender == conditions.gender);
    }

    Next() {
        this.counter = this.counter + 1;
        if (this.counter == this.filtered.length) {
            alert('There is no matches');
            window.location.href = 'index.html';         
        }
        this.filtered[this.counter].Render();
    }

    Render() {
        this.filtered[this.counter].Render();      
    }
}